# Reporte DevExpress de Compra de Combustible — Instrucciones de instalación

Soluciona el botón "Imprimir Compra" que nunca mostraba el reporte (el código
que lo mostraba estaba comentado y el diseño usaba data-binding frágil contra
entidades de EF Core).

El nuevo reporte replica el formato del reporte HTML que ya funciona:
logo + datos de empresa (NIT, REEUP, cuenta bancaria, teléfonos, correo),
folio con 6 dígitos, estado con color, datos generales, resumen de importes,
tabla de detalles con totales, comentario y firmas.

## Archivos incluidos

| Acción | Archivo |
|---|---|
| **REEMPLAZAR** | `DXComnTransp.Module/Reports/CompraCombustibleReport.cs` |
| **ELIMINAR** | `DXComnTransp.Module/Controllers/ImprimirCompraCombustibleController.cs` |
| **AGREGAR** | `DXComnTransp.Win/Controllers/CompraCombustibleImprimirController.cs` |
| **AGREGAR** | `DXComnTransp.Blazor.Server/Controllers/CompraCombustibleImprimirController.cs` |
| **AGREGAR** | `DXComnTransp.Blazor.Server/Controllers/ReporteCompraPdfEndpointController.cs` |
| **AGREGAR** | `DXComnTransp.Blazor.Server/Services/ReporteCompraPdfCache.cs` |

## Pasos en Visual Studio 2022

1. **Commit de seguridad primero** (por si hay que revertir):
   ```powershell
   git add -A
   git commit -m "Backup antes del nuevo reporte DevExpress"
   ```

2. **Cierra Visual Studio** (o al menos cierra la solución).

3. Copia los archivos sobre tu carpeta de la solución respetando las rutas
   (la estructura de carpetas del zip es idéntica a la del proyecto):
   - Reemplaza `CompraCombustibleReport.cs`
   - Elimina `ImprimirCompraCombustibleController.cs`
   - Agrega los otros 4 archivos nuevos

4. Abre la solución y **compila** (Ctrl+Shift+B).

5. **Prueba en Win:** ejecuta `DXComnTransp.Win` → Operaciones → Compra de
   combustible → selecciona una compra → botón **"Imprimir Compra"** →
   se abre la vista previa DevExpress (puede imprimirse o exportarse a
   PDF/Excel desde ahí).

6. **Prueba en Blazor:** ejecuta `DXComnTransp.Blazor.Server` → mismo botón →
   se abre el reporte en PDF en una pestaña nueva del navegador.

## Por qué ahora no da errores

- El reporte **no usa entidades de EF Core como DataSource**: todo el
  contenido (empresa, compra, detalles, totales) se copia a texto y a
  DTOs planos *antes* de renderizar. Sin lazy-loading, sin contexto vivo,
  sin sorpresas.
- **No depende de ReportDataV2** ni del almacenamiento de reportes de XAF:
  es un reporte ad-hoc 100% en código.
- El botón ya no pasa por reflexión ni por `ReportServiceController`
  (que era la parte que estaba comentada/rota):
  - **Win** usa `ReportPrintTool.ShowPreviewDialog()` (API nativa).
  - **Blazor** exporta a PDF y lo abre por token en pestaña nueva
    (mismo mecanismo ya probado del reporte HTML).

## Notas

- Si Win diera error de compilación por `ReportPrintTool` (no debería:
  DevExpress.ExpressApp.ReportsV2.Win ya lo trae), agrega al
  `DXComnTransp.Win.csproj`:
  ```xml
  <PackageReference Include="DevExpress.XtraReports" Version="22.1.3" />
  ```
- El botón antiguo "Imprimir Reporte" (HTML) sigue funcionando igual;
  conviene dejarlo: el HTML es la vista rápida y el DevExpress el
  imprimible formal.
- Los PDF en caché del lado web expiran a los 30 minutos (igual que el HTML).
